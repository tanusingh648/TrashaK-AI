# Student Result System
A simple student result management project.