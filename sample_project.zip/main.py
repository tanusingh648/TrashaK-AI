def main():
    print('Student Result System')

if __name__ == '__main__':
    main()
